GROUP DETAILS:

1.KROVVIDI KUSUMANJALI
2.SOWMIKA
3.SAMHITHA
4.AFREEN
5.HEMALATHA

Project Idea:BONE MARROW DONATION 

Prerequisites:  nodemon
npm install nodemon express mongoose dotenv ejs path body-parser mangoose express-session connect-mongodb-session 

The main js file to run in our project is server.js
 go to vscode terminal and type nodemon server.js now the mongodb is connected
and Server is started on http://127.0.0.1:3000 or http://localhost:3000
By opening any of the above links in the browser our main home page will be displayed to us,
 from which we can go to many other pages like
donor and patent forms etc . ON the navbar if we register first and login we will be redirected to track order. if you fill any form in 
the pages all the data will be stored in database mongodb.
Now to see the admin page where we can do all the CRUD operations we have to go to browser and
 browse http://127.0.0.1:3000/admin or http://localhost:3000/admin
here we can see the table showing the registers as an admin now you can edit or delete or create any register then that data will be again stored to the database
whenever you enter as a new register the data will be updated in database and as well as in admin table. At any time as an admin you can edit,create,delete the detailer

**git link**
https://github.com/Sowmika024/FSD_PROJECT



